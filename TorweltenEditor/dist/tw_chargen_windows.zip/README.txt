=======================================================================
                              READ ME
=======================================================================



         DIES IST EINE PRE-ALPHA MIT DER VERSIONSNUMMER 0.0!!



Programmaufruf: 
Der Einstieg in das Programm erfolgt über tw_chargen.py

../
build/		Dateien von Py2Exe aus dem Kompiliervorgang
chars/		Standardverzeichnis für Charakterdateien
data/		Grundlegende Datendateien 
dist/		Exportverzeichnis der Windows-Stand-Alone Version
fonts/		Hier finden sich die Schriftarten
images/		Bilddateien
ui_img/		UI-Grafiken [NUR FatCow FarmFresh!]
templates/  Templates für den PDF Export

Das Programm benötigt Python 3

neben der Standard-Library werden die folgenden Module benötigt:

* PIL (oder Pillow) - pip install pillow
* reportlab - pip install reportlab


Windows Version: 
Im Verzeichnis ./dist befindet sich eine mit Py2Exe erstellte Stand-
Alone-Version des Programms. Sie wird via tw_chargen.exe aufgerufen


=======================================================================
